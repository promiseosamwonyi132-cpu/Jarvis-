# Jarvis for Android

Double-clap to wake. Greets you as "princess" in a British voice, tells you the weather and your reminders, then listens for commands.

## Build and install
1. Install Android Studio (free) on a PC or Mac.
2. File > Open > choose this `jarvis-android` folder. Let Gradle sync (needs internet).
3. On the tablet: Settings > About tablet > tap "Build number" 7 times, then Developer options > USB debugging.
4. Plug the tablet in, press the green Run button. (Or Build > Build APK and copy the APK to the tablet.)

## First-run setup (in the app, once)
1. Grant permissions (microphone, phone, contacts, SMS, location, notifications).
2. Notification access: turn Jarvis ON (this is how it reads mail and messages).
   If it is greyed out: Settings > Apps > Jarvis > ⋮ menu > "Allow restricted settings", then try again.
3. Display over other apps: allow (lets it open apps).
4. Battery: set Jarvis to "Unrestricted" / not optimised, so it keeps listening.
Then press START JARVIS. A "Jarvis is listening" notification stays on while it runs.

## Voice commands
- "What's the weather" / "what time is it" / "what's the date"
- "Remind me to call the pharmacy in 20 minutes" / "...at 5:30 pm"
- "Read my reminders" / "clear my reminders"
- "Read my emails" / "read my messages" (from notifications, e.g. Gmail, WhatsApp, Messages)
- "Text Mary saying I'm running late" (asks to confirm, then sends)
- "Call Mary" or "call 0803 123 4567"
- "Set a timer for 5 minutes", "open YouTube"
- When a call comes in it announces the caller and asks whether to answer.

## Known limits
- Android will not let apps auto-start the microphone after a reboot (Android 14+). Open the app and press Start after restarting.
- Reading mail/messages works from notifications received while the listener is on, not by opening your whole inbox.
- Wi-Fi-only tablets have no phone/SMS features; they are skipped.
- Voice quality depends on the installed text-to-speech engine. Install "Speech Services by Google" and download the English (UK) voice.
- Speech recognition uses Google's service and needs internet unless offline English is downloaded.
- This code has not been compiled or run. Expect a few small fixes on first build; paste any error here.
