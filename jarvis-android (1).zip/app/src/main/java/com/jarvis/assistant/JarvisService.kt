package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.sqrt

class JarvisService : android.app.Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_WAKE = "com.jarvis.assistant.WAKE"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val NAME = "princess"
        private const val CHANNEL = "jarvis_service"
        private val YES = Regex("\\b(yes|yeah|yep|sure|please|go ahead|do it|send it|answer|pick up|accept)\\b")
        private val NO = Regex("\\b(no|nope|decline|reject|ignore|hang up|cancel)\\b")

        @Volatile var instance: JarvisService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = ArrayList<Pair<String, () -> Unit>>()
    private val callbacks = HashMap<String, () -> Unit>()

    @Volatile private var clapRunning = false
    private var clapThread: Thread? = null
    @Volatile private var busy = false

    private var recognizer: SpeechRecognizer? = null
    private var awaiting: (() -> String)? = null
    private var afterFinish: (() -> Unit)? = null
    private var callActive = false
    private var ringNumber: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        Reminders.rescheduleAll(this)
        if (intent?.action == ACTION_WAKE) main.post { wakeUp() } else startClapDetector()
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        stopClapDetector()
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis is listening")
            .setContentText("Clap twice to wake me")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /* ---------------- Voice out: calm British TTS ---------------- */

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.language = Locale.UK
        t.setSpeechRate(0.9f)
        t.setPitch(0.9f)
        try {
            // Prefer an installed en-GB male voice (Google TTS: ...-gbd-... / ...-rjs-...).
            val v = t.voices?.firstOrNull {
                it.locale == Locale.UK && !it.isNetworkConnectionRequired &&
                    (it.name.contains("gbd") || it.name.contains("rjs"))
            }
            if (v != null) t.voice = v
        } catch (e: Exception) { }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                val id = utteranceId ?: return
                main.post { callbacks.remove(id)?.invoke() }
            }
            @Suppress("OVERRIDE_DEPRECATION")
            override fun onError(utteranceId: String?) { onDone(utteranceId) }
        })
        ttsReady = true
        pending.forEach { speak(it.first, it.second) }
        pending.clear()
    }

    private fun speak(text: String, done: () -> Unit = {}) {
        if (!ttsReady) { pending.add(text to done); return }
        val id = UUID.randomUUID().toString()
        callbacks[id] = done
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
    }

    fun speakReminder(text: String) {
        main.post { speak("Excuse me, $NAME. A reminder: $text.") }
    }

    /* ---------------- Double-clap detector ---------------- */

    private fun startClapDetector() {
        if (clapRunning || !has(Manifest.permission.RECORD_AUDIO)) return
        clapRunning = true
        clapThread = thread(name = "jarvis-clap") {
            val rate = 16000
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                @SuppressLint("MissingPermission")
                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 4096)
                )
                r
            } catch (e: Exception) { clapRunning = false; return@thread }
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); clapRunning = false; return@thread }

            val buf = ShortArray(512)
            var base = 600.0
            var lastClap = 0L
            var lastEdge = 0L
            rec.startRecording()
            while (clapRunning) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                var peak = 0
                var sum = 0.0
                for (i in 0 until n) {
                    val s = buf[i].toInt()
                    val a = abs(s)
                    if (a > peak) peak = a
                    sum += s.toDouble() * s
                }
                val rms = sqrt(sum / n)
                val now = SystemClock.elapsedRealtime()
                if (!busy && peak > maxOf(12000.0, base * 8) && rms > base * 3 && now - lastEdge > 120) {
                    lastEdge = now
                    val gap = now - lastClap
                    if (gap > 150 && gap < 900) {
                        lastClap = 0
                        main.post { wakeUp() }
                    } else lastClap = now
                }
                base = base * 0.995 + rms * 0.005
            }
            try { rec.stop() } catch (e: Exception) { }
            rec.release()
        }
    }

    private fun stopClapDetector() {
        clapRunning = false
        try { clapThread?.join(600) } catch (e: Exception) { }
        clapThread = null
    }

    /* ---------------- Voice in ---------------- */

    private fun listen(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { onResult(""); return }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        var delivered = false
        fun deliver(s: String) {
            if (delivered) return
            delivered = true
            main.post { r.destroy() }
            recognizer = null
            onResult(s)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                deliver(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
            }
            override fun onError(error: Int) = deliver("")
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
        )
    }

    /* ---------------- Wake sequence ---------------- */

    private fun wakeUp() {
        if (busy) return
        busy = true
        stopClapDetector()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            hour < 12 -> "Good morning"
            hour < 18 -> "Good afternoon"
            else -> "Good evening"
        }
        speak("$greeting, $NAME.")
        fetchWeather { w ->
            speak("$w ${reminderSummary()} How may I help?") { converse(0) }
        }
    }

    private fun converse(turn: Int) {
        if (turn >= 6) { finish(); return }
        listen { q ->
            if (q.isBlank()) { finish(); return@listen }
            handle(q) { reply, keepGoing ->
                speak(reply) { if (keepGoing) converse(turn + 1) else finish() }
            }
        }
    }

    private fun finish() {
        awaiting = null
        busy = false
        startClapDetector()
        afterFinish?.let { afterFinish = null; it() }
    }

    /* ---------------- Commands ---------------- */

    private fun handle(raw: String, reply: (String, Boolean) -> Unit) {
        val s = raw.lowercase(Locale.UK).trim()

        awaiting?.let { act ->
            awaiting = null
            if (YES.containsMatchIn(s)) reply(act(), true) else reply("Very well, $NAME. Cancelled.", true)
            return
        }
        if (Regex("\\b(stop|never ?mind|go to sleep|that's all|that is all|goodbye|thank you)\\b").containsMatchIn(s)) {
            reply("Very well, $NAME. I'm here when you need me.", false); return
        }
        if (s.contains("weather") || s.contains("forecast") || s.contains("temperature")) {
            fetchWeather { reply(it, true) }; return
        }
        Regex("remind me (?:to |that )?(.+)").find(s)?.let { m ->
            val (text, due) = Reminders.parse(m.groupValues[1])
            Reminders.add(this, text, due)
            val fmt = SimpleDateFormat("h:mm a", Locale.UK)
            reply(
                if (due > 0) "Done, $NAME. I'll remind you to $text at ${fmt.format(Date(due))}."
                else "Noted, $NAME. Reminder added: $text.", true
            )
            return
        }
        if (s.contains("reminder")) {
            if (s.contains("clear") || s.contains("delete")) {
                Reminders.clear(this); reply("All reminders cleared.", true)
            } else reply(reminderSummary(), true)
            return
        }
        if (Regex("(read|check|any|new).*(e-?mail|mail|inbox)").containsMatchIn(s)) { reply(readInbox(true), true); return }
        if (Regex("(read|check|any|new).*(message|text|whatsapp)").containsMatchIn(s)) { reply(readInbox(false), true); return }

        Regex("(?:send (?:a )?(?:text|message) to|text|message) (.+?) (?:saying|that says|and say|and tell (?:him|her|them)) (.+)")
            .find(s)?.let { m ->
                val who = m.groupValues[1].removePrefix("to ").trim()
                val body = m.groupValues[2].trim()
                val c = resolveContact(who)
                if (c == null) reply("I couldn't find $who in your contacts, $NAME.", true)
                else {
                    awaiting = { sendSms(c.second, body) }
                    reply("I'll text ${c.first}: $body. Shall I send it?", true)
                }
                return
            }
        Regex("(?:call|phone|ring|dial) (.+)").find(s)?.let { m ->
            val c = resolveContact(m.groupValues[1].trim())
            if (c == null) reply("I couldn't find that contact, $NAME.", true)
            else {
                afterFinish = { placeCall(c.second) }
                reply("Calling ${c.first}.", false)
            }
            return
        }
        Regex("timer for (\\d+) (second|minute|hour)s?").find(s)?.let { m ->
            val n = m.groupValues[1].toLong()
            val ms = n * when (m.groupValues[2]) { "second" -> 1000L; "minute" -> 60_000L; else -> 3_600_000L }
            main.postDelayed({ speak("Your ${m.groupValues[1]} ${m.groupValues[2]} timer is up, $NAME.") }, ms)
            reply("Timer set for ${m.groupValues[1]} ${m.groupValues[2]}s.", true)
            return
        }
        if (Regex("what('s| is)?( the)? time|what time").containsMatchIn(s)) {
            reply("It is " + SimpleDateFormat("h:mm a", Locale.UK).format(Date()) + ".", true); return
        }
        if (Regex("(date|what day)").containsMatchIn(s)) {
            reply("Today is " + SimpleDateFormat("EEEE d MMMM", Locale.UK).format(Date()) + ".", true); return
        }
        Regex("open (.+)").find(s)?.let { m -> reply(openApp(m.groupValues[1].trim()), true); return }

        reply("I'm afraid I can't do that one yet, $NAME.", true)
    }

    private fun reminderSummary(): String {
        val o = Reminders.outstanding(this)
        if (o.isEmpty()) return "You have no outstanding reminders."
        val fmt = SimpleDateFormat("h:mm a", Locale.UK)
        val items = o.joinToString(". ") { (t, due) -> if (due > 0) "$t, at ${fmt.format(Date(due))}" else t }
        return "You have ${o.size} outstanding reminder${if (o.size > 1) "s" else ""}. $items."
    }

    private fun readInbox(mail: Boolean): String {
        val list = if (mail) Inbox.mail() else Inbox.chats()
        val what = if (mail) "emails" else "messages"
        if (!has(Manifest.permission.RECORD_AUDIO)) return "I need permission first."
        if (list.isEmpty()) return "I have no new $what to read, $NAME. If you expected some, check that notification access is enabled for me."
        return "You have ${list.size} recent $what. " + list.joinToString(" ") { "From ${it.title}: ${it.text.take(160)}." }
    }

    /* ---------------- Contacts, calls, texts, apps ---------------- */

    private fun resolveContact(spoken: String): Pair<String, String>? {
        val digits = spoken.filter { it.isDigit() || it == '+' }
        if (digits.length >= 6) return spoken to digits
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$spoken%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) to c.getString(1) }
        return null
    }

    private fun lookupName(number: String): String? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    @Suppress("DEPRECATION")
    private fun sendSms(number: String, body: String): String = try {
        if (!has(Manifest.permission.SEND_SMS)) "I don't have permission to send texts, $NAME."
        else {
            val sm = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(number, null, sm.divideMessage(body), null, null)
            "Message sent, $NAME."
        }
    } catch (e: Exception) { "I'm afraid the message failed to send." }

    private fun placeCall(number: String) {
        try {
            if (has(Manifest.permission.CALL_PHONE))
                getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", number, null), Bundle())
        } catch (e: Exception) { }
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        fun label(r: android.content.pm.ResolveInfo) = r.loadLabel(pm).toString().lowercase(Locale.UK)
        val hit = apps.firstOrNull { label(it) == name } ?: apps.firstOrNull { label(it).contains(name) }
            ?: return "I couldn't find an app called $name."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "I couldn't open that."
        afterFinish = { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }
        return "Opening ${hit.loadLabel(pm)}."
    }

    /* ---------------- Incoming calls ---------------- */

    fun announceCall(number: String?) {
        main.post {
            if (number != null) ringNumber = number
            if (callActive) return@post
            callActive = true
            main.postDelayed({ doAnnounce() }, 700)
        }
    }

    fun callEnded() = main.post { callActive = false; ringNumber = null }

    private fun doAnnounce() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); callbacks.clear()
        busy = true
        stopClapDetector()
        val n = ringNumber
        val who = if (n == null) "an unknown number"
        else lookupName(n) ?: n.toCharArray().joinToString(" ")
        speak("Excuse me, $NAME. Incoming call from $who. Shall I answer?") {
            listen { q ->
                val s = q.lowercase(Locale.UK)
                try {
                    val tm = getSystemService(TelecomManager::class.java)
                    if (has(Manifest.permission.ANSWER_PHONE_CALLS)) {
                        if (YES.containsMatchIn(s)) tm.acceptRingingCall()
                        else if (NO.containsMatchIn(s) && Build.VERSION.SDK_INT >= 28) tm.endCall()
                    }
                } catch (e: Exception) { }
                finish()
            }
        }
    }

    /* ---------------- Weather ---------------- */

    @SuppressLint("MissingPermission")
    private fun lastLocation(): Pair<Double, Double>? {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        if (has(Manifest.permission.ACCESS_COARSE_LOCATION) || has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            val lm = getSystemService(LocationManager::class.java)
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l: Location? = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            val b = best
            if (b != null) {
                prefs.edit().putString("loc", "${b.latitude},${b.longitude}").apply()
                return b.latitude to b.longitude
            }
        }
        val saved = prefs.getString("loc", null)?.split(",") ?: return null
        return saved[0].toDouble() to saved[1].toDouble()
    }

    private fun describe(code: Int) = when (code) {
        0 -> "clear skies"; 1 -> "mostly clear skies"; 2 -> "partly cloudy skies"; 3 -> "overcast skies"
        45, 48 -> "fog"; 51, 53, 55 -> "drizzle"; 61 -> "light rain"; 63 -> "rain"; 65 -> "heavy rain"
        71, 73, 75 -> "snow"; 80, 81 -> "showers"; 82 -> "heavy showers"; 95, 96, 99 -> "thunderstorms"
        else -> "mixed conditions"
    }

    private fun fetchWeather(cb: (String) -> Unit) {
        val loc = lastLocation()
        if (loc == null) { cb("I couldn't find your location for the weather."); return }
        thread {
            val msg = try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=${loc.first}&longitude=${loc.second}" +
                        "&current=temperature_2m,weather_code" +
                        "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val j = JSONObject(c.inputStream.bufferedReader().readText())
                val cur = j.getJSONObject("current")
                val d = j.getJSONObject("daily")
                "It is ${Math.round(cur.getDouble("temperature_2m"))} degrees, with ${describe(cur.getInt("weather_code"))}. " +
                    "Today's high is ${Math.round(d.getJSONArray("temperature_2m_max").getDouble(0))} and the low " +
                    "${Math.round(d.getJSONArray("temperature_2m_min").getDouble(0))}, with a " +
                    "${d.getJSONArray("precipitation_probability_max").getInt(0)} percent chance of rain."
            } catch (e: Exception) { "I couldn't reach the weather service just now." }
            main.post { cb(msg) }
        }
    }
}
