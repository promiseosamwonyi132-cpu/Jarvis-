package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun perms(): Array<String> {
        val p = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        return p.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF050B18.toInt())
        }
        fun btn(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { onClick() } })
        }

        root.addView(TextView(this).apply {
            text = "JARVIS"; textSize = 32f; setTextColor(0xFF4FD1FF.toInt())
        })
        status = TextView(this).apply {
            setTextColor(0xFFD8ECFF.toInt())
            text = "Do steps 1 to 4 once, then press Start."
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(status)

        btn("1. Grant permissions") { requestPermissions(perms(), 1) }
        btn("2. Allow notification access (to read mail and messages)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Allow display over other apps (to open apps)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("4. Stop battery optimisation for Jarvis") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("START JARVIS") { startJarvis() }
        btn("Wake now (test)") {
            if (hasMic()) ContextCompat.startForegroundService(
                this, Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_WAKE)
            ) else status.text = "Grant permissions first."
        }
        btn("Stop Jarvis") {
            startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
            status.text = "Jarvis stopped."
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startJarvis() {
        if (!hasMic()) { status.text = "Grant permissions first (step 1)."; return }
        ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        status.text = "Jarvis is running. Clap twice."
    }
}
