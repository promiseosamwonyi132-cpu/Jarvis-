package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        val id = intent.getLongExtra("id", 0L)
        Reminders.markDone(context, id)

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis_reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.notify(
            id.toInt(),
            NotificationCompat.Builder(context, "jarvis_reminders")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Reminder")
                .setContentText(text)
                .setAutoCancel(true)
                .build()
        )
        // If Jarvis is running, say it out loud too.
        JarvisService.instance?.speakReminder(text)
    }
}
