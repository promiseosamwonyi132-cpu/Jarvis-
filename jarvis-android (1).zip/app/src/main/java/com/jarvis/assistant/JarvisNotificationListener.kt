package com.jarvis.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class InboxItem(val pkg: String, val title: String, val text: String, val time: Long)

/** Recent mail / chat notifications, so Jarvis can read them out. */
object Inbox {
    private val items = ArrayList<InboxItem>()
    private val mailApps = setOf(
        "com.google.android.gm", "com.microsoft.office.outlook",
        "com.yahoo.mobile.client.android.mail", "com.samsung.android.email.provider"
    )
    private val chatApps = setOf(
        "com.whatsapp", "com.google.android.apps.messaging", "com.samsung.android.messaging",
        "org.telegram.messenger", "com.android.mms"
    )

    @Synchronized fun add(i: InboxItem) {
        items.removeAll { it.pkg == i.pkg && it.title == i.title && it.text == i.text }
        items.add(0, i)
        while (items.size > 40) items.removeAt(items.size - 1)
    }

    @Synchronized fun mail(): List<InboxItem> = items.filter { it.pkg in mailApps }.take(5)
    @Synchronized fun chats(): List<InboxItem> = items.filter { it.pkg in chatApps }.take(5)
}

class JarvisNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        try { activeNotifications?.forEach { record(it) } } catch (e: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = record(sbn)

    private fun record(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        Inbox.add(InboxItem(sbn.packageName, title, text, sbn.postTime))
    }
}
