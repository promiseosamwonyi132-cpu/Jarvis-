package com.jarvis.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Reminder storage + alarm scheduling. Survives restarts of the service. */
object Reminders {
    private const val KEY = "reminders"

    private fun prefs(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    private fun load(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString(KEY, "[]")) } catch (e: Exception) { JSONArray() }

    private fun save(c: Context, a: JSONArray) = prefs(c).edit().putString(KEY, a.toString()).apply()

    /** Pulls "in 10 minutes" / "at 5:30 pm" out of the sentence. Returns (cleanText, dueMillisOr0). */
    fun parse(raw: String): Pair<String, Long> {
        var text = raw
        var due = 0L
        val rel = Regex("\\bin (\\d+|an?|one) (minute|hour)s?\\b").find(text)
        val abs = Regex("\\bat (\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?").find(text)
        if (rel != null) {
            val n = rel.groupValues[1].toLongOrNull() ?: 1L
            val unit = if (rel.groupValues[2] == "hour") 3_600_000L else 60_000L
            due = System.currentTimeMillis() + n * unit
            text = text.replace(rel.value, "")
        } else if (abs != null) {
            var h = abs.groupValues[1].toInt()
            val m = abs.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = abs.groupValues[3]
            if (ap.startsWith("p") && h < 12) h += 12
            if (ap.startsWith("a") && h == 12) h = 0
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis < System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
            due = cal.timeInMillis
            text = text.replace(abs.value, "")
        }
        text = text.replace(Regex("\\s+"), " ").trim().removePrefix("to ").trim()
        return text to due
    }

    fun add(c: Context, text: String, due: Long) {
        val id = System.currentTimeMillis()
        val a = load(c)
        a.put(JSONObject().put("id", id).put("text", text).put("due", due).put("done", false))
        save(c, a)
        if (due > 0) schedule(c, id, text, due)
    }

    /** Outstanding reminders as (text, due or 0). */
    fun outstanding(c: Context): List<Pair<String, Long>> {
        val a = load(c)
        val out = ArrayList<Pair<String, Long>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (!o.optBoolean("done")) out.add(o.getString("text") to o.optLong("due"))
        }
        return out
    }

    fun markDone(c: Context, id: Long) {
        val a = load(c)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optLong("id") == id) o.put("done", true)
        }
        save(c, a)
    }

    fun clear(c: Context) = save(c, JSONArray())

    fun rescheduleAll(c: Context) {
        val a = load(c)
        val now = System.currentTimeMillis()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val due = o.optLong("due")
            if (!o.optBoolean("done") && due > now) schedule(c, o.getLong("id"), o.getString("text"), due)
        }
    }

    private fun schedule(c: Context, id: Long, text: String, due: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, id.toInt(),
            Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi)
    }
}
